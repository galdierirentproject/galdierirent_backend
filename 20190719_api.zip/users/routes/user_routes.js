'use strict'

var express = require('express');
var userController = require('../controllers/user_controller');
var api = express.Router();
api.get('/avatar/:id', userController.downloadImgProfile);

//******************************UPLOAD FILES**********************************************//
// api.post('/uploadsecurity', imageController.uploadFile);
// api.post('/profile', imageController.profile);
// api.get('/avatar/:id', imageController.uploadImgProfile);
// api.get('/filelist/:id', imageController.fileList);
//*****************PONT********************************************************//

module.exports = api;