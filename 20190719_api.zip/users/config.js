module.exports = {

    'secret': 'g@ld!&r!R&nt2018_',
    'database': 'mongodb://grent:GRent82_@46.37.21.15:27017/galdierirent0002',
    'database_localhost': 'mongodb://localhost:27017/galdierirent0002',
    'privkey_keys': 'keys/privkey.pem',
    'cert_keys': 'keys/cert.pem',
    'privkey': '/opt/psa/var/modules/letsencrypt/etc/live/api3.consulenti-galdierirent.it/privkey.pem',
    'cert': '/opt/psa/var/modules/letsencrypt/etc/live/api3.consulenti-galdierirent.it/cert.pem',
    'ip': '46.37.21.15',
    'localhost': '127.0.0.1'
};