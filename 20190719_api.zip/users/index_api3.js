'use strict'
var mongoose = require('mongoose');
var app = require('./app');
var fs = require('fs');
//*************************************UNCOMENT FOR HTTPS ****************************************//
var https = require('https');
var config = require('./config');
var port = process.env.PORT || 4105;
var privateKey = fs.readFileSync(config.privkey_keys, 'utf8');
var certificate = fs.readFileSync(config.cert_keys, 'utf8');
var credentials = { key: privateKey, cert: certificate };
var httpsServer = https.createServer(credentials, app);
var colors = require('colors');
//var httpServer = http.createServer(app);
mongoose.connect(config.database, { useNewUrlParser: true }, (err, res) => {
    if (err) {
        throw err;
    } else {
        console.log(`connect to mongo OK: ${port}`.america);
        httpsServer.listen(port, config.ip, () => {
            // console.log('🚀 Server ready', );
            console.log(`APIREST/GraphQL ${Date()}`.green);
            console.log(`https:api3.consulenti-galdierirent.it (${config.ip}:${port})`);
        });

    }
});