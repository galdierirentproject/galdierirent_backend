'use strict'

var mongoose = require('mongoose');

var schema = mongoose.Schema;

var register_loginLogoutSchema = schema({
    user: String,
    operation:String,
    data_creazione : { type: Date, default: Date.now}
}, {
    versionKey: false 
});


module.exports = mongoose.model('loginlogout', register_loginLogoutSchema);