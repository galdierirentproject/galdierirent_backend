'use strict'

var mongoose = require('mongoose');

var schema = mongoose.Schema;
var ObjectID = require('mongodb').ObjectID;
var navbar = schema({
    primaryBackground: String,
    secondaryBackground: String,
    folded: Boolean,
    hidden: Boolean,
    position: String,
    variant: String
});
var toolbar = schema({
    customBackgroundColor: Boolean,
    background: String,
    hidden: Boolean,
    position: String,
});
var footer = schema({
    customBackgroundColor: Boolean,
    background: String,
    hidden: Boolean,
    position: String,
});
var sidepanel = schema({
    hidden: Boolean,
    position: String,
});
var layout = schema({
    style: String,
    width: String,
    navbar,
    toolbar,
    footer,
    sidepanel
});
var userSchema = schema({
    // sha512:{salt: String, passwordHash:String},
    file: [schema.Types.Mixed],
    img: [schema.Types.Mixed],
    nome: String,
    cognome: String,
    username: String,
    password: String,
    email: String,
    state: String,
    ruolo: String,
    profile_img: String,
    room: String,
    telefono: String,
    cellulare: String,
    titolo: String,
    azienda: String,
    indirizzo: String,
    cap: String,
    provincia: String,
    comune: String,
    cf: String,
    piva: String,
    token: String,
    sede: String,
    fuseconfig:{colorTheme: String,customScrollbars: Boolean,layout},
    profile_img: String,
    regionesociale:String,
    tipologiacliente : String,
    inizioattivita:Boolean,
    nome_point:String,
    consulente:{_id:String,username:String},
    data_creazione: { type: Date, default: Date.now }
}, {
    versionKey: false // You should be aware of the outcome after set to false
});
module.exports = mongoose.model('user', userSchema);