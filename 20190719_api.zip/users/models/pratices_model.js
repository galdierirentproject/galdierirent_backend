'use strict'
// const User = require('./user_model');
// const State = require('./states_model');

// const User = mongoose.model('User', userSchema);
// const State = mongoose.model('State', stateSchema);

var mongoose = require('mongoose');

var schema = mongoose.Schema;
var userSchema = schema({
    nome: String,
    cognome: String,
    username: String,
    password: String,
    email: String,
    state: String,
    ruolo: String,
    profile_img: String,
    room: String,
    telefono: String,
    cellulare: String,
    titolo: String,
    azienda: String,
    indirizzo: String,
    cap: String,
    provincia: String,
    comune: String,
    cf: String,
    piva: String,
    data_creazione : { type: Date, default: Date.now }

})
const User = {
        nome: String,
        cognome: String,
        username: String,
        password: String,
        email: String,
        state: String,
        ruolo: String,
        profile_img: String,
        room: String,
        telefono: String,
        cellulare: String,
        titolo: String,
        azienda: String,
        indirizzo: String,
        cap: String,
        provincia: String,
        comune: String,
        cf: String,
        piva: String,
        data_creazione : { type: Date, default: Date.now }

    }
const User_Division = {
    user: User,
    division: String
}
    // object note
var user_DivisionSchema =schema({
    user: userSchema,
    division: String
})
    // object note
var noteSchema = schema({
    note: String,
    date: { type: Date, default: Date.now }
})
const Note = {
    note: String,
    date: { type: Date, default: Date.now }
}
    // object result (esito)
var resultSchema = schema({
    number: Number,
    description: String,
})
const Result = {
    number: Number,
    description: String,
}
var description_StateSchema = schema({
    state_number: Number,
    description: String,
})
const Description_State = {
    state_number: Number,
    description: String,
}
var content_StateSchema = schema({
    description: description_StateSchema,
    result: Result,
    note: [noteSchema]
})
const Content_State = {
        description: Description_State,
        result: Result,
        note: [Note]
    }
var int_collectionSchema = schema({
    state_name: String, // nome della collections in mongo DB
    state_number: Number, // identificativo numerico della collections
    content: [content_StateSchema]
})
    // object collection
const int_Collection = {
        state_name: String, // nome della collections in mongo DB
        state_number: Number, // identificativo numerico della collections
        content: [Content_State]
    }
    // state
var stateSchema = schema({
    user_division: user_DivisionSchema,
    date: { type: Date, default: Date.now },
    int_collection: int_collectionSchema
})
var State = {
    user_division: User_Division,
    date: { type: Date, default: Date.now },
    int_collection: int_Collection
}
var praticesSchema = schema({

    infocar: String,
    marca: String,
    codice_marca: String,
    modello: String,
    codice_modello: String,
    alimentazione: String,
    allestimento: String,
    optional: String,
    colore_esterno: String,
    colore_interno: String,
    durata: Number,
    chilometri: Number,
    provvigioni: Number,
    provvigioni_richieste: Number,
    provvigioni_definitive: Number,
    provvigioni_percentuale: Number,
    forma_anticipo: String,
    anticipo: Number,
    casa_locatrice_preferenza: String,
    casa_locatrice: String,
    prodotto: String,
    codice_costruttore: String,
    franchigia_rca: String,
    franchigia_furto: String,
    franchigia_kasko: String,
    sostituzione_pneumatici: Boolean,
    auto_sostitutiva: Boolean,
    auto_sostitutiva_gruppo: String,
    fuel_card: Boolean,
    luogo_consegna: String,
    pneumatici_invernali_performance: String,
    pneumatici_invernali_metodo: String,
    pneumatici_invernali_numero: Number,
    pneumatici_estivi_performance: String,
    pneumatici_estivi_metodo: String,
    pneumatici_estivi_numero: Number,
    file: [schema.Types.Mixed],
    note: [noteSchema],
    note_allegati: [noteSchema],
    note_preventivo: [noteSchema],
    states: [stateSchema],
    user_seller: userSchema,
    client_costumer: userSchema,
    data: { type: Date, default: Date.now }


}, {
    versionKey: false // You should be aware of the outcome after set to false
});
const state = mongoose.model('state', stateSchema);
const pratices = mongoose.model('pratice', praticesSchema);

const state_000 = mongoose.model('000_state', praticesSchema);
const state_001 = mongoose.model('001_state', praticesSchema);
const state_002 = mongoose.model('002_state', praticesSchema);
const state_003 = mongoose.model('003_state', praticesSchema);
const state_004 = mongoose.model('004_state', praticesSchema);
const state_005 = mongoose.model('005_state', praticesSchema);
const state_006 = mongoose.model('006_state', praticesSchema);
const state_007 = mongoose.model('007_state', praticesSchema);
const state_008 = mongoose.model('008_state', praticesSchema);
const state_009 = mongoose.model('009_state', praticesSchema);
const state_010 = mongoose.model('010_state', praticesSchema);
const state_011 = mongoose.model('011_state', praticesSchema);
const state_012 = mongoose.model('012_state', praticesSchema);
module.exports = {
    state,
    state_000,
    state_001,
    state_002,
    state_003,
    state_004,
    state_005,
    state_006,
    state_007,
    state_008,
    state_009,
    state_010,
    state_011,
    state_012,
    pratices
}