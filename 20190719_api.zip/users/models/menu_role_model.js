'use strict'

var mongoose = require('mongoose');
var schema = mongoose.Schema;

var menuRoleSchema = schema({
    role: String,
    file:String
}, {
    versionKey: false
});


module.exports = mongoose.model('menu_role', menuRoleSchema);