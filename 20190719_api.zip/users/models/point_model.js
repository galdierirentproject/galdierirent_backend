'use strict'

var mongoose = require('mongoose');

var schema = mongoose.Schema;
var ObjectID = require('mongodb').ObjectID;
var objectId = mongoose.Schema.Types.ObjectId;
var locationSchema = schema({
    // Mongoose interpets this as 'loc is an object with 2 keys, type and coordinates'
    location: { type: String, coordinates: [Number] },
    // Mongoose interprets this as 'name is a String'
    name: String
}, { _id: false, typeKey: '$type' }); // limit '$type' key means this object is a type declaration

var pointSchema = schema({
    id_areamanager_lista: [objectId],
    id_consulenti_lista: [objectId],
    id_pointmanager: [objectId],
    nome_point: String,
    telefono: String,
    cellulare: String,
    email: String,
    azienda: String,
    indirizzo: String,
    cap: String,
    provincia: String,
    comune: String,
    cf: String,
    piva: String,
    note: String,
    data_creazione: { type: Date, default: Date.now },
    coordinates: locationSchema
}, {
    versionKey: false // You should be aware of the outcome after set to false
});
module.exports = mongoose.model('point', pointSchema);