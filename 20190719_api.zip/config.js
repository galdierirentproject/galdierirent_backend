module.exports = {

    'secret': 'g@ld!&r!R&nt2018_',
    'database': 'mongodb://grent:GRent82_@95.110.145.154:27017/galdierirent0002',
    'database_localhost': 'mongodb://localhost:27017/graphql2_db_001',
    'privkey_keys': 'keys/privkey.pem',
    'cert_keys': 'keys/cert.pem',
    'privkey': '/opt/psa/var/modules/letsencrypt/etc/live/graphql2.galdierirent.info/privkey.pem',
    'cert': '/opt/psa/var/modules/letsencrypt/etc/live/graphql2.galdierirent.info/cert.pem',
    'ip': '95.110.145.155',
    'localhost': '127.0.0.1',
    'dominio': 'graphql2.galdieriretns.info',
    'graphql_port': 4106
};